package tech.CaisseManager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaisseManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CaisseManagerApplication.class, args);
	}

}
